Goes with this video here (made by me, ThinkWithGames aka Goldenlion5648): https://youtu.be/yTkJv8tMO7g 
